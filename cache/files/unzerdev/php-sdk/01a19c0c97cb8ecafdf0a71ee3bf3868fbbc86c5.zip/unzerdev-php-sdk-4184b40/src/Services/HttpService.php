<?php
/**
 * This service provides for functionalities concerning http transactions.
 *
 * Copyright (C) 2020 - today Unzer E-Com GmbH
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @link  https://docs.unzer.com/
 *
 * @author  Simon Gabriel <development@unzer.com>
 *
 * @package  UnzerSDK\Services
 */
namespace UnzerSDK\Services;

use UnzerSDK\Adapter\CurlAdapter;
use UnzerSDK\Adapter\HttpAdapterInterface;
use UnzerSDK\Exceptions\UnzerApiException;
use UnzerSDK\Unzer;
use UnzerSDK\Resources\AbstractUnzerResource;
use RuntimeException;
use function in_array;
use const PHP_VERSION;

class HttpService
{
    private const URL_PART_STAGING_ENVIRONMENT = 'stg';
    private const URL_PART_DEVELOPMENT_ENVIRONMENT = 'dev';

    /** @var HttpAdapterInterface $httpAdapter */
    private $httpAdapter;

    /** @var EnvironmentService $environmentService */
    private $environmentService;

    //<editor-fold desc="Getters/Setters">

    /**
     * Returns the currently set HttpAdapter.
     * If it is not set it will create a CurlRequest by default and return it.
     *
     * @return HttpAdapterInterface
     *
     * @throws RuntimeException
     */
    public function getAdapter(): HttpAdapterInterface
    {
        if (!$this->httpAdapter instanceof HttpAdapterInterface) {
            $this->httpAdapter = new CurlAdapter();
        }
        return $this->httpAdapter;
    }

    /**
     * @param HttpAdapterInterface $httpAdapter
     *
     * @return HttpService
     */
    public function setHttpAdapter(HttpAdapterInterface $httpAdapter): HttpService
    {
        $this->httpAdapter = $httpAdapter;
        return $this;
    }

    /**
     * @return EnvironmentService
     */
    public function getEnvironmentService(): EnvironmentService
    {
        if (!$this->environmentService instanceof EnvironmentService) {
            $this->environmentService = new EnvironmentService();
        }
        return $this->environmentService;
    }

    /**
     * @param EnvironmentService $environmentService
     *
     * @return HttpService
     */
    public function setEnvironmentService(EnvironmentService $environmentService): HttpService
    {
        $this->environmentService = $environmentService;
        return $this;
    }

    //</editor-fold>

    /**
     * send post request to payment server
     *
     * @param $uri string url of the target system
     * @param AbstractUnzerResource $resource
     * @param string                $httpMethod
     *
     * @return string
     *
     * @throws UnzerApiException An UnzerApiException is thrown if there is an error returned on API-request.
     * @throws RuntimeException  A RuntimeException is thrown when there is an error while using the SDK.
     */
    public function send(
        $uri = null,
        AbstractUnzerResource $resource = null,
        $httpMethod = HttpAdapterInterface::REQUEST_GET
    ): string {
        if (!$resource instanceof AbstractUnzerResource) {
            throw new RuntimeException('Transfer object is empty!');
        }
        $unzerObj = $resource->getUnzerObject();

        // perform request
        $url     = $this->getEnvironmentUrl($uri);
        $payload = $resource->jsonSerialize();
        $headers = $this->composerHttpHeaders($unzerObj);
        $this->initRequest($url, $payload, $httpMethod, $headers);
        $httpAdapter  = $this->getAdapter();
        $response     = $httpAdapter->execute();
        $responseCode = $httpAdapter->getResponseCode();
        $httpAdapter->close();

        // handle response
        try {
            $this->handleErrors($responseCode, $response);
        } finally {
            $this->debugLog($unzerObj, $payload, $headers, $responseCode, $httpMethod, $url, $response);
        }

        return $response;
    }

    /**
     * Initializes and returns the http request object.
     *
     * @param string $uri
     * @param string $payload
     * @param string $httpMethod
     * @param $httpHeaders
     *
     * @throws RuntimeException
     */
    private function initRequest($uri, $payload, $httpMethod, $httpHeaders): void
    {
        $httpAdapter = $this->getAdapter();
        $httpAdapter->init($uri, $payload, $httpMethod);
        $httpAdapter->setUserAgent(Unzer::SDK_TYPE);
        $httpAdapter->setHeaders($httpHeaders);
    }

    /**
     * Handles error responses by throwing an UnzerApiException with the returned messages and error code.
     * Returns doing nothing if no error occurred.
     *
     * @param string      $responseCode
     * @param string|null $response
     *
     * @throws UnzerApiException
     */
    private function handleErrors($responseCode, $response): void
    {
        if ($response === null) {
            throw new UnzerApiException('The Request returned a null response!');
        }

        $responseObject = json_decode($response, false);
        if (!is_numeric($responseCode) || (int)$responseCode >= 400 || isset($responseObject->errors)) {
            $code            = null;
            $errorId         = null;
            $customerMessage = $code;
            $merchantMessage = $customerMessage;
            if (isset($responseObject->errors[0])) {
                $errors          = $responseObject->errors[0];
                $merchantMessage = $errors->merchantMessage ?? '';
                $customerMessage = $errors->customerMessage ?? '';
                $code            = $errors->code ?? '';
            }
            if (isset($responseObject->id)) {
                $errorId = $responseObject->id;
                if (IdService::getResourceTypeFromIdString($errorId) !== 'err') {
                    $errorId = null;
                }
            }

            throw new UnzerApiException($merchantMessage, $customerMessage, $code, $errorId);
        }
    }

    /**
     * @param Unzer       $unzerObj
     * @param string      $payload
     * @param mixed       $headers
     * @param int         $responseCode
     * @param string      $httpMethod
     * @param string      $url
     * @param string|null $response
     */
    public function debugLog(
        Unzer $unzerObj,
        $payload,
        $headers,
        $responseCode,
        $httpMethod,
        string $url,
        $response
    ): void {
        // mask auth string
        $authHeader = explode(' ', $headers['Authorization']);
        $authHeader[1] = ValueService::maskValue($authHeader[1]);
        $headers['Authorization'] = implode(' ', $authHeader);

        // log request
        $unzerObj->debugLog($httpMethod . ': ' . $url);
        $writingOperations = [HttpAdapterInterface::REQUEST_POST, HttpAdapterInterface::REQUEST_PUT];
        $unzerObj->debugLog('Headers: ' . json_encode($headers, JSON_UNESCAPED_SLASHES));
        if (in_array($httpMethod, $writingOperations, true)) {
            $unzerObj->debugLog('Request: ' . $payload);
        }

        // log response
        $response = $response ?? '';
        $unzerObj->debugLog(
            'Response: (' . $responseCode . ') ' .
            json_encode(json_decode($response, false), JSON_UNESCAPED_SLASHES)
        );
    }

    /**
     * Returns the environment url.
     *
     * @param $uri
     *
     * @return string
     */
    private function getEnvironmentUrl($uri): string
    {
        $envUrl = [];
        switch ($this->getEnvironmentService()->getPapiEnvironment()) {
            case EnvironmentService::ENV_VAR_VALUE_STAGING_ENVIRONMENT:
                $envUrl[] = self::URL_PART_STAGING_ENVIRONMENT;
                break;
            case EnvironmentService::ENV_VAR_VALUE_DEVELOPMENT_ENVIRONMENT:
                $envUrl[] = self::URL_PART_DEVELOPMENT_ENVIRONMENT;
                break;
            default:
                break;
        }
        $envUrl[] = Unzer::BASE_URL;
        return 'https://' . implode('-', $envUrl) . '/' . Unzer::API_VERSION . $uri;
    }

    /**
     * @param Unzer $unzer
     *
     * @return array
     */
    public function composerHttpHeaders(Unzer $unzer): array
    {
        $locale      = $unzer->getLocale();
        $key         = $unzer->getKey();
        $httpHeaders = [
            'Authorization' => 'Basic ' . base64_encode($key . ':'),
            'Content-Type'  => 'application/json',
            'SDK-VERSION'   => Unzer::SDK_VERSION,
            'SDK-TYPE'      => Unzer::SDK_TYPE,
            'PHP-VERSION'   => PHP_VERSION
        ];
        if (!empty($locale)) {
            $httpHeaders['Accept-Language'] = $locale;
        }

        return $httpHeaders;
    }
}
