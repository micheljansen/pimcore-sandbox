<?php


namespace Safe\Exceptions;

interface SafeExceptionInterface extends \Throwable
{

}
