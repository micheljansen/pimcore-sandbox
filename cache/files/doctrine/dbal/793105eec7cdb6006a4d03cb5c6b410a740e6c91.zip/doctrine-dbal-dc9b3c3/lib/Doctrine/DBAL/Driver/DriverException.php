<?php

namespace Doctrine\DBAL\Driver;

/**
 * @deprecated Use {@link Exception} instead
 *
 * @psalm-immutable
 */
interface DriverException extends Exception
{
}
