<?php

namespace Doctrine\DBAL\Driver\PDO;

use Doctrine\DBAL\Driver\PDOConnection;

class Connection extends PDOConnection
{
}
