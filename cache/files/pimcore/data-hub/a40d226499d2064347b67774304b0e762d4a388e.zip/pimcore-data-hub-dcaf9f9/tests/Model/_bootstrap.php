<?php


\Pimcore\Bootstrap::kernel();
