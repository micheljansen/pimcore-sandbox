<?php

declare(strict_types=1);

namespace ProxyManager\Signature\Exception;

/**
 * Exception marker for exceptions from the signature sub-component
 */
interface ExceptionInterface
{
}
