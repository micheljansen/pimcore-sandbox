<?php

return [
    'Names' => [
        'da' => 'الدنماركية',
    ],
    'LocalizedNames' => [
    ],
];
