<?php

return [
    'Names' => [
        'GMD' => [
            0 => 'D',
            1 => 'Gambian Dalasi',
        ],
    ],
];
