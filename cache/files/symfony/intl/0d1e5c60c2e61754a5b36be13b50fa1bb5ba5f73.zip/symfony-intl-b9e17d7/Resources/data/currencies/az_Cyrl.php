<?php

return [
    'Names' => [
        'AZN' => [
            0 => '₼',
            1 => 'AZN',
        ],
    ],
];
