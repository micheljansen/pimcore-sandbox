<?php

return [
    'Names' => [
        'KES' => [
            0 => 'Ksh',
            1 => 'Kenyan Shilling',
        ],
    ],
];
