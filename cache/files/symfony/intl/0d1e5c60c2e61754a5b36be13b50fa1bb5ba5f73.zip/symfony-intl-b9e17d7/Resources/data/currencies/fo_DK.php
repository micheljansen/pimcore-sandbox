<?php

return [
    'Names' => [
        'DKK' => [
            0 => 'kr.',
            1 => 'donsk króna',
        ],
    ],
];
