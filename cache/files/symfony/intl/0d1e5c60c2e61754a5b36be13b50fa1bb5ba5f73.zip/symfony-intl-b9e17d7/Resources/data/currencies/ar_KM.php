<?php

return [
    'Names' => [
        'KMF' => [
            0 => 'CF',
            1 => 'فرنك جزر القمر',
        ],
    ],
];
