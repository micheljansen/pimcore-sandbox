## Sub-split of Flysystem for SFTP using phpseclib2.

```bash
composer require league/flysystem-sftp
```

View the [documentation](https://flysystem.thephpleague.com/v2/docs/adapter/sftp/).
